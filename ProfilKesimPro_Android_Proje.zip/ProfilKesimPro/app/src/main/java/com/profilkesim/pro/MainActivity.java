package com.profilkesim.pro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, entries, result;
    EditText stock, kerf, newPart, newCount;
    final ArrayList<int[]> pieces = new ArrayList<>();
    int dp(float value) { return (int)(getResources().getDisplayMetrics().density*value+0.5f); }
    TextView label(String s, int size) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(Color.rgb(25,38,55)); v.setPadding(0,dp(9),0,dp(9)); return v;
    }
    EditText number(String hint, String value) {
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); return e;
    }
    LinearLayout section() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(16),dp(13),dp(16),dp(13)); return l; }
    Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    void message(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this); root=section(); scroll.addView(root); setContentView(scroll);
        TextView title=label("PROFİL KESİM PRO",25); title.setGravity(Gravity.CENTER); root.addView(title);
        root.addView(label("Profil boyu (mm)",16)); stock=number("Örn. 6000","6000"); root.addView(stock);
        root.addView(label("Testere payı / kesim (mm)",16)); kerf=number("Örn. 3","3"); root.addView(kerf);
        root.addView(label("Kesilecek parçalar (mm)",17)); entries=section(); root.addView(entries);
        newPart=number("Parça uzunluğu (mm)",""); root.addView(newPart);
        newCount=number("Adet","1"); root.addView(newCount);
        Button add=button("+ Parça ekle"); root.addView(add);
        add.setOnClickListener(v->{ try {
            int length=(int)Math.round(Double.parseDouble(newPart.getText().toString().replace(',','.')));
            int count=Integer.parseInt(newCount.getText().toString());
            if(length<=0||count<=0||count>10000){message("Geçerli ölçü ve adet girin.");return;}
            pieces.add(new int[]{length,count}); drawEntries(); newPart.setText(""); newCount.setText("1");
        }catch(Exception x){message("Ölçü ve adet sayısal olmalı.");}});
        Button calc=button("KESİM PLANI HESAPLA"); root.addView(calc);
        result=section(); root.addView(result);
        calc.setOnClickListener(v->calculate());
        root.addView(label("Yöntem: Büyükten küçüğe sıralama ve en uygun boya yerleştirme. Testere payı her parçada hesaplanır. Bu yöntem her durumda matematiksel optimumu garanti etmez.",12));
    }
    void drawEntries(){
        entries.removeAllViews();
        for(int i=0;i<pieces.size();i++){
            final int index=i; int[] p=pieces.get(i);
            LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            TextView t=label(p[0]+" mm  ×  "+p[1]+" adet",16); line.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=button("Sil"); line.addView(remove); remove.setOnClickListener(v->{pieces.remove(index);drawEntries();});
            entries.addView(line);
        }
    }
    void calculate(){
        result.removeAllViews();
        try {
            int length=(int)Math.round(Double.parseDouble(stock.getText().toString().replace(',','.')));
            int gap=(int)Math.round(Double.parseDouble(kerf.getText().toString().replace(',','.')));
            if(length<=0||gap<0||pieces.isEmpty()){message("Profil boyu, testere payı ve parça girin.");return;}
            ArrayList<Integer> items=new ArrayList<>();
            for(int[] p: pieces) for(int i=0;i<p[1];i++)items.add(p[0]);
            items.sort(Collections.reverseOrder());
            ArrayList<ArrayList<Integer>> bars=new ArrayList<>(); ArrayList<Long> used=new ArrayList<>();
            for(int p:items){
                long need=(long)p+gap;
                if(need>length){message(p+" mm parça profil boyuna sığmıyor.");return;}
                int best=-1;long minRemaining=Long.MAX_VALUE;
                for(int j=0;j<used.size();j++){long rem=length-used.get(j)-need;if(rem>=0&&rem<minRemaining){minRemaining=rem;best=j;}}
                if(best<0){ArrayList<Integer> b=new ArrayList<>(); b.add(p);bars.add(b);used.add(need);}
                else{bars.get(best).add(p);used.set(best,used.get(best)+need);}
            }
            result.addView(label("SONUÇ: "+bars.size()+" boy profil gerekiyor",21));
            long waste=0;
            for(int i=0;i<bars.size();i++){
                long rem=length-used.get(i);waste+=rem;
                StringBuilder sb=new StringBuilder("Boy "+(i+1)+": ");
                for(int j=0;j<bars.get(i).size();j++){if(j>0)sb.append(" + ");sb.append(bars.get(i).get(j));}
                sb.append(" mm\nKalan: ").append(rem).append(" mm");
                result.addView(label(sb.toString(),15));
            }
            result.addView(label("Toplam artan: "+waste+" mm | Toplam parça: "+items.size(),17));
        }catch(Exception e){message("Lütfen geçerli sayılar girin.");}
    }
}

# Profil Kesim Pro

Android uygulaması: profil boyu, kesim payı, kesilecek ölçüler ve adetler girilir; otomatik kesim planı oluşturulur.

## APK oluşturma

Bu klasörü GitHub deposunun kök dizinine yükleyin. GitHub Actions sekmesinde Android APK iş akışı çalışır. Başarılı çalışmanın Artifacts bölümünden ProfilKesimPro-APK ZIP dosyasını indirin, içindeki app-debug.apk dosyasını Android cihazınıza yükleyin.

Alternatif: Android Studio ile klasörü açıp Build > Build APK(s) seçin.

Not: Bu ZIP bir APK değildir, APK derlemek için kaynak projedir.
